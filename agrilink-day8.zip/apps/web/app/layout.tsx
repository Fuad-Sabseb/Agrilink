import type { Metadata } from "next";
import localFont from "next/font/local";
import "./globals.css";
import { AuthProvider } from "../lib/auth/AuthContext";

const geistSans = localFont({
  src: "./fonts/GeistVF.woff",
  variable: "--font-geist-sans",
  weight: "100 900",
});
const geistMono = localFont({
  src: "./fonts/GeistMonoVF.woff",
  variable: "--font-geist-mono",
  weight: "100 900",
});

export const metadata: Metadata = {
  title: "AgriLink — Jimma Zone",
  description:
    "Market intelligence, buyers, and logistics for Jimma Zone farmers.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="om">
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-agrilink-green-dark`}
      >
        <AuthProvider>{children}</AuthProvider>
      </body>
    </html>
  );
}
